# libmuse (version 1.0.0)

libmuse is a library for interfacing with Muse headbands, including finding
paired Muses, connecting to them, reading their state, and receiving packets
for raw EEG data and all other values. You can use it in your own applications,
subject to the terms of our license.

We intend for it to eventually work on every platform that people have an
interest in using to connect to Muse. For now, we support Android.

The library consists of two parts: a core in C++ and a platform-specific
interface in whatever language your platform writes its interfaces in: Java for
Android, Objective-C for iOS, C++ for desktop.

## Android quick start

We've included an example app at `examples/TestLibMuseAndroid`. Just import it
into your IDE and modify the code under `src/` to make it do what you want it
to do.

## Including it in your own application

Drop libmuse.jar and libmuse_android.so into the right place in your project.
Open `doc/index.html` in your browser to read the API documentation.
