var searchData=
[
  ['setnotchfrequency',['setNotchFrequency',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a376924f192a6021ef87d78fd40dd6219',1,'com::interaxon::libmuse::Muse']]],
  ['setpreset',['setPreset',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#abd85c07d60a80370162047d3ed0572c6',1,'com::interaxon::libmuse::Muse']]]
];
