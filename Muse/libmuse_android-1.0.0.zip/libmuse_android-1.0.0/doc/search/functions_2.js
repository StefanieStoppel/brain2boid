var searchData=
[
  ['enabledatatransmission',['enableDataTransmission',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#affafd3e2f090f55505c7ecd853dc07f0',1,'com::interaxon::libmuse::Muse']]],
  ['execute',['execute',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#ab97147212515d47a6c0a95c6495b26ed',1,'com::interaxon::libmuse::Muse']]]
];
