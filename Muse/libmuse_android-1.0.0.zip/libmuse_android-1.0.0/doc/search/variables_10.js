var searchData=
[
  ['unknown',['UNKNOWN',['../enumcom_1_1interaxon_1_1libmuse_1_1_connection_state.html#a94c6f2b868c20e78ebc0c9b4484e36d4',1,'com::interaxon::libmuse::ConnectionState']]],
  ['up_5fdown',['UP_DOWN',['../enumcom_1_1interaxon_1_1libmuse_1_1_accelerometer.html#a6aa0f0c9688bff78c08e980ac721443d',1,'com::interaxon::libmuse::Accelerometer']]]
];
