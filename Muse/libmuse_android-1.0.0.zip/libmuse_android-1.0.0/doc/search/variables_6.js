var searchData=
[
  ['gamma_5fabsolute',['GAMMA_ABSOLUTE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a8be2562e053cc34e5701595cb94aad58',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['gamma_5frelative',['GAMMA_RELATIVE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a2ac8fbae34e40b4460d2c1807e39347d',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['gamma_5fscore',['GAMMA_SCORE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a634b6ff26deca975b9d42ac7af39d6c4',1,'com::interaxon::libmuse::MuseDataPacketType']]]
];
