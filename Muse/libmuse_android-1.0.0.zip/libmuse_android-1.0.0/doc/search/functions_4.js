var searchData=
[
  ['receivemuseartifactpacket',['receiveMuseArtifactPacket',['../classcom_1_1interaxon_1_1libmuse_1_1_muse_data_listener.html#ad0cd32e9588a0159b22b416c51e57cf3',1,'com::interaxon::libmuse::MuseDataListener']]],
  ['receivemuseconnectionpacket',['receiveMuseConnectionPacket',['../classcom_1_1interaxon_1_1libmuse_1_1_muse_connection_listener.html#a547de4eca7ce2a34a2fa788542526755',1,'com::interaxon::libmuse::MuseConnectionListener']]],
  ['receivemusedatapacket',['receiveMuseDataPacket',['../classcom_1_1interaxon_1_1libmuse_1_1_muse_data_listener.html#a3a724ced8f8b41040b1849cc1eb81c56',1,'com::interaxon::libmuse::MuseDataListener']]],
  ['refreshpairedmuses',['refreshPairedMuses',['../classcom_1_1interaxon_1_1libmuse_1_1_muse_manager.html#a58794dce3c9aed0531db499a161464bc',1,'com::interaxon::libmuse::MuseManager']]],
  ['registerconnectionlistener',['registerConnectionListener',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a2abaefc390fb0482f15eef868bea9e5d',1,'com::interaxon::libmuse::Muse']]],
  ['registerdatalistener',['registerDataListener',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a71b734b92dd97f879d8446fca004d05f',1,'com::interaxon::libmuse::Muse']]],
  ['renameheadband',['renameHeadband',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a0b956174cd29245f9fd28289e19bc93e',1,'com::interaxon::libmuse::Muse']]],
  ['runasynchronously',['runAsynchronously',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a5d2934b9405f7f8ab47e7965f67d9677',1,'com::interaxon::libmuse::Muse']]]
];
