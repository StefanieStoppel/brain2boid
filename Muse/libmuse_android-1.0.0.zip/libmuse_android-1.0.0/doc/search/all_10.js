var searchData=
[
  ['unknown',['UNKNOWN',['../enumcom_1_1interaxon_1_1libmuse_1_1_connection_state.html#a94c6f2b868c20e78ebc0c9b4484e36d4',1,'com::interaxon::libmuse::ConnectionState']]],
  ['unregisteralllisteners',['unregisterAllListeners',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a0a0580eb3fa517469bc89e873dcd5956',1,'com::interaxon::libmuse::Muse']]],
  ['unregisterconnectionlistener',['unregisterConnectionListener',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a6d03cdf36b73f500890b44ffc29348de',1,'com::interaxon::libmuse::Muse']]],
  ['unregisterdatalistener',['unregisterDataListener',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#aba53ec6e4569e345370103eda2eba5e9',1,'com::interaxon::libmuse::Muse']]],
  ['up_5fdown',['UP_DOWN',['../enumcom_1_1interaxon_1_1libmuse_1_1_accelerometer.html#a6aa0f0c9688bff78c08e980ac721443d',1,'com::interaxon::libmuse::Accelerometer']]]
];
