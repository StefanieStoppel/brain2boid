var searchData=
[
  ['accelerometer',['Accelerometer',['../enumcom_1_1interaxon_1_1libmuse_1_1_accelerometer.html',1,'com::interaxon::libmuse']]],
  ['accelerometer',['ACCELEROMETER',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#ad21fc894a80c5100748cc9f15a6509d6',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['alpha_5fabsolute',['ALPHA_ABSOLUTE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#ab4e30b2441bbc1432618b122f4e315d6',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['alpha_5frelative',['ALPHA_RELATIVE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a134f7df5b2823ee42f32ab45c8ee6beb',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['alpha_5fscore',['ALPHA_SCORE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a387c2487e7fc3f270700470352ae6130',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['artifacts',['ARTIFACTS',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a1777f81ef9884070160dc4c273f0173e',1,'com::interaxon::libmuse::MuseDataPacketType']]]
];
