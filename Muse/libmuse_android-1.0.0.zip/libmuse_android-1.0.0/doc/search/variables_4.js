var searchData=
[
  ['eeg',['EEG',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a4d2d761e09288e2eae30fd9b95fae8b3',1,'com::interaxon::libmuse::MuseDataPacketType']]]
];
