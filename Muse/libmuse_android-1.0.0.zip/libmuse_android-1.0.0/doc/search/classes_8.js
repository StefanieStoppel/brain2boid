var searchData=
[
  ['senderinformation',['SenderInformation',['../classcom_1_1interaxon_1_1libmuse_1_1_sender_information.html',1,'com::interaxon::libmuse']]]
];
