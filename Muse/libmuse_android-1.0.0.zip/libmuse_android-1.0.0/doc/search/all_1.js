var searchData=
[
  ['battery',['Battery',['../enumcom_1_1interaxon_1_1libmuse_1_1_battery.html',1,'com::interaxon::libmuse']]],
  ['battery',['BATTERY',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a3c132527c4da36c894de8ca273d26468',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['beta_5fabsolute',['BETA_ABSOLUTE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a0200c1b48bb553110af1ae763e70cb0b',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['beta_5frelative',['BETA_RELATIVE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a7cc9fd87adf34d6617f810ca2fab1d5e',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['beta_5fscore',['BETA_SCORE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#abd3a5682a768be0f9b362716bf8591e8',1,'com::interaxon::libmuse::MuseDataPacketType']]]
];
