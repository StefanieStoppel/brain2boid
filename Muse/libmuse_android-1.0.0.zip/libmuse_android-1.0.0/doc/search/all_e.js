var searchData=
[
  ['sdk_5fint',['SDK_INT',['../classcom_1_1interaxon_1_1libmuse_1_1_lib_muse_version.html#a1addc92e6e2c7083417fcd5ca6783bae',1,'com::interaxon::libmuse::LibMuseVersion']]],
  ['sdk_5fversion',['SDK_VERSION',['../classcom_1_1interaxon_1_1libmuse_1_1_lib_muse_version.html#a4559b783d95d4ac6690369c0a580c321',1,'com::interaxon::libmuse::LibMuseVersion']]],
  ['senderinformation',['SenderInformation',['../classcom_1_1interaxon_1_1libmuse_1_1_sender_information.html',1,'com::interaxon::libmuse']]],
  ['setnotchfrequency',['setNotchFrequency',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a376924f192a6021ef87d78fd40dd6219',1,'com::interaxon::libmuse::Muse']]],
  ['setpreset',['setPreset',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#abd85c07d60a80370162047d3ed0572c6',1,'com::interaxon::libmuse::Muse']]]
];
