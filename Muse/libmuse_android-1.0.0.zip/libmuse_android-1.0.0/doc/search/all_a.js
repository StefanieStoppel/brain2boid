var searchData=
[
  ['notch_5f50hz',['NOTCH_50HZ',['../enumcom_1_1interaxon_1_1libmuse_1_1_notch_frequency.html#aeaf68f3dc809f70076b236c3f897b93a',1,'com::interaxon::libmuse::NotchFrequency']]],
  ['notch_5f60hz',['NOTCH_60HZ',['../enumcom_1_1interaxon_1_1libmuse_1_1_notch_frequency.html#ab4086fd5e27e8ad5d3dc116f0b710c0e',1,'com::interaxon::libmuse::NotchFrequency']]],
  ['notchfrequency',['NotchFrequency',['../enumcom_1_1interaxon_1_1libmuse_1_1_notch_frequency.html',1,'com::interaxon::libmuse']]]
];
