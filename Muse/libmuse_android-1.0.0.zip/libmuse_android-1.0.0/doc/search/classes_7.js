var searchData=
[
  ['notchfrequency',['NotchFrequency',['../enumcom_1_1interaxon_1_1libmuse_1_1_notch_frequency.html',1,'com::interaxon::libmuse']]]
];
