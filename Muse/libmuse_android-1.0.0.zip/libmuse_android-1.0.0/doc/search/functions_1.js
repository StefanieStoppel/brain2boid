var searchData=
[
  ['disconnect',['disconnect',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#ae843476831a3bf09a73b31552bb9ea3f',1,'com::interaxon::libmuse::Muse']]]
];
