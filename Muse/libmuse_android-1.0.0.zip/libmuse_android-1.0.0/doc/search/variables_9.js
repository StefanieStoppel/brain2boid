var searchData=
[
  ['millivolts',['MILLIVOLTS',['../enumcom_1_1interaxon_1_1libmuse_1_1_battery.html#a587f6c16776c8f42b462b6587aeda2f0',1,'com::interaxon::libmuse::Battery']]]
];
