var searchData=
[
  ['delta_5fabsolute',['DELTA_ABSOLUTE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#ac7bfe246dad7c8172360fe64a2ce0f26',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['delta_5frelative',['DELTA_RELATIVE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#abaeee2d8ff81a86dd395cef7f0e1c0c3',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['delta_5fscore',['DELTA_SCORE',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a0ff15b3f120c59c3c7e095b4fe12d9f8',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['disconnected',['DISCONNECTED',['../enumcom_1_1interaxon_1_1libmuse_1_1_connection_state.html#ad3579be62c7c1cd368c22dd05eb6806a',1,'com::interaxon::libmuse::ConnectionState']]],
  ['drl',['DRL',['../enumcom_1_1interaxon_1_1libmuse_1_1_drl_ref.html#a3aaf911664989e22c8ae3d6cfb0dc499',1,'com::interaxon::libmuse::DrlRef']]],
  ['drl_5fref',['DRL_REF',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a470c995536b5631e6deb5ae3666a3e40',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['dropped_5faccelerometer',['DROPPED_ACCELEROMETER',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a0ee37c03cfa547ac37b87b437b756bf6',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['dropped_5feeg',['DROPPED_EEG',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#aee77ca6a2d7dc9f373a1469c540854fa',1,'com::interaxon::libmuse::MuseDataPacketType']]]
];
