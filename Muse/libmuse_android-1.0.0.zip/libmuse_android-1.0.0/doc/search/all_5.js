var searchData=
[
  ['forward_5fbackward',['FORWARD_BACKWARD',['../enumcom_1_1interaxon_1_1libmuse_1_1_accelerometer.html#ad9eec0f142621682c1748da83c9cdbdb',1,'com::interaxon::libmuse::Accelerometer']]],
  ['fp1',['FP1',['../enumcom_1_1interaxon_1_1libmuse_1_1_eeg.html#a076eef1ec297b6089c3a63fd640b540d',1,'com::interaxon::libmuse::Eeg']]],
  ['fp2',['FP2',['../enumcom_1_1interaxon_1_1libmuse_1_1_eeg.html#a7710e24ee4018e3f4747980b46d523b6',1,'com::interaxon::libmuse::Eeg']]]
];
