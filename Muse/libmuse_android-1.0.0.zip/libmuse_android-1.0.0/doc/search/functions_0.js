var searchData=
[
  ['connect',['connect',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#a5ce9854a4981adbc79d6b6f7ece3fb0b',1,'com::interaxon::libmuse::Muse']]]
];
