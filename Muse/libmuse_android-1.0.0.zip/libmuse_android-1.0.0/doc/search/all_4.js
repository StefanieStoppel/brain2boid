var searchData=
[
  ['eeg',['Eeg',['../enumcom_1_1interaxon_1_1libmuse_1_1_eeg.html',1,'com::interaxon::libmuse']]],
  ['eeg',['EEG',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a4d2d761e09288e2eae30fd9b95fae8b3',1,'com::interaxon::libmuse::MuseDataPacketType']]],
  ['enabledatatransmission',['enableDataTransmission',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#affafd3e2f090f55505c7ecd853dc07f0',1,'com::interaxon::libmuse::Muse']]],
  ['execute',['execute',['../classcom_1_1interaxon_1_1libmuse_1_1_muse.html#ab97147212515d47a6c0a95c6495b26ed',1,'com::interaxon::libmuse::Muse']]]
];
