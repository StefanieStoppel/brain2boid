var searchData=
[
  ['quantization',['QUANTIZATION',['../enumcom_1_1interaxon_1_1libmuse_1_1_muse_data_packet_type.html#a0af686b96621c3af5b4a775c4a5f924d',1,'com::interaxon::libmuse::MuseDataPacketType']]]
];
